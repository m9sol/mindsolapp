### This directory contains all data to build docker images for db handlers testing
