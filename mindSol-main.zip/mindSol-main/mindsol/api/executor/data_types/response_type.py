class RESPONSE_TYPE:
    __slots__ = ()
    OK = 'ok'
    TABLE = 'table'
    ERROR = 'error'


RESPONSE_TYPE = RESPONSE_TYPE()
