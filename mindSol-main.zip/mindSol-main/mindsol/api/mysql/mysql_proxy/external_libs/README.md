Here we put libraries or helpers that are borrowed from other projects

- Try only to use MIT code
- If the code you are using is not MIT licensed, email management@mindsdb.com before proceeding