from flask_restx import Namespace

ns_conf = Namespace('sql', description='API for sql commands')
