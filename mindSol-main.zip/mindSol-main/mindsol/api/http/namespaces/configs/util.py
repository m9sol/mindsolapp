from flask_restx import Namespace

ns_conf = Namespace('util', description='General routes')
